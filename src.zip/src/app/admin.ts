export class Admin {
    adminId:number;
    adminName:String;
    password:String;
    adminEmail:String;
}
