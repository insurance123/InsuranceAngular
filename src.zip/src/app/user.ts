export class User {
    userId: Number;
    userName: String;
    userEmail: String;
    userPhone: String;
    password:String;
    dateOfBirth: String;
}
